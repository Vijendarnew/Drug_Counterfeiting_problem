'use strict';

const pharmacontract = require('./pharma-contract');
module.exports.pharmacontract = pharmacontract;
module.exports.contracts = [pharmacontract];
